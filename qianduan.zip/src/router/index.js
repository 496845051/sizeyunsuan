import Vue from 'vue'
import Router from 'vue-router'
import Index from '../pages/Index'
import Main from '../pages/Main/Main'
import Personal from '../pages/Personal/Personal'
import Homework from '../pages/Homework/Homework'
import DoWork from '../pages/DoWork/DoWork'
import WorkDetail from '../pages/WorkDetail/WorkDetail'
import ChooseWork from '../pages/ChooseWork/ChooseWork'
import LoginMain from '../pages/Login/Index'
import Login from '../pages/Login/Login/Login'
import Register from '../pages/Login/Register/Register'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index,
      children:[
        {
          path: '/',
          name: 'Main',
          component: Main,
          value:"1"
        },
        {
          path: '/Login',
          name: 'LoginMain',
          component: LoginMain,
          value:"2",
          children:[
            {
              path: '/',
              name: 'Login',
              component: Login,
              value:"2-1"
            },
            {
              path: '/Login/Register',
              name: 'Register',
              component: Register,
              value:"2-2"
            }
          ]
        },
        {
          path: '/Personal',
          name: 'Personal',
          component: Personal,
          value:"3"
        },
        {
          path: '/Homework',
          name: 'Homework',
          component: Homework,
          value:"4"
        },
        {
          path: '/DoWork',
          name: 'DoWork',
          component: DoWork,
          value:"5"
        },
        {
          path: '/ChooseWork',
          name: 'ChooseWork',
          component: ChooseWork,
          value:"6"
        },
        {
          path: '/WorkDetail',
          name: 'WorkDetail',
          component: WorkDetail,
          value:"7"
        },
      ]
    }
  ]
})
