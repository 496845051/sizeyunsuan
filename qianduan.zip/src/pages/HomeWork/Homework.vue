<template>
  <Row style="margin-top: 30px">
    <Col :offset="1" :span="22">
      <Row :gutter="20">
        <Col :span="5" v-for="item,value in homeworkList">
          <Row class="card">
            <Row :class="{ 'card-caption primary': true, 'primary': item.status, 'warning': !item.status }">
              <span>{{item.name}}</span>
              <span style="float: right;padding-right: 10px" v-if="item.status"><Icon type="checkmark"></Icon> 已完成</span>
              <span style="float: right;padding-right: 10px" v-else><Icon type="close"></Icon> 未完成</span>
            </Row>
            <Row class="ivu-card-body">
              <p>题目数：{{item.number}}</p>
              <p>截止时间：{{item.limitTime}}</p>
              <p>布置者：{{item.creator}} 老师</p>
              <Button type="error" v-if="!item.status" style="float: right" @click="doHomeWork">开始答题</Button>
              <Button type="primary" v-else style="float: right" @click="checkWorkDetail">答题情况</Button>
            </Row>
          </Row>
        </Col>
      </Row>
    </Col>
  </Row>
</template>

<script>
  export default {
    name: "",
    data() {
      return {
        date: "",
        time: "",
        homeworkList: [
          {
            name: "作业1",
            limitTime: "2018年5月4日 20:46:25",
            number: 30,
            creator: "张三",
            status: false
          },
          {
            name: "作业2",
            limitTime: "2018年5月4日 20:46:25",
            number: 30,
            creator: "张三",
            status: true
          },
          {
            name: "作业3",
            limitTime: "2018年5月4日 20:46:25",
            number: 30,
            creator: "张三",
            status: true
          }
        ]
      }
    },
    created: function () {

    },
    methods: {
      doHomeWork:function () {
        this.$router.push('/DoWork')
      },
      checkWorkDetail:function () {
        this.$router.push('/WorkDetail')
      }
    }
  }
</script>

<style scoped>
  .card {
    background: white;
    border-radius: 5px;
    overflow: hidden;
  }

  .card .card-caption {
    padding: 12px;
    color: white;
  }

  .primary {
    background-color: #2d8cf0;
  }

  .warning {
    background-color: #ed3f14;
  }
  .card .ivu-card-body p{
    margin-bottom: 5px;
  }
</style>
