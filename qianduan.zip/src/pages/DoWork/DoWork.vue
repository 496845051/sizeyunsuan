<template>
  <Row>
    <Row style="margin-top: 100px">
      <Col :offset="6" :span="12">
        <Card>
          <p slot="title">第{{(quesIndex+1)}}题</p>
          <Row>
            <Col :span="4">
              <Button type="text"><Icon type="chevron-left"></Icon> 上一题</Button>
            </Col>
            <!--<Col :span="16" style="text-align: center">-->
              <!--<Button type="primary" shape="circle">搜索</Button>-->
            <!--</Col>-->
            <Col :span="20" style="text-align: right">
              <Button type="text">下一题 <Icon type="chevron-right"></Icon></Button>
            </Col>
          </Row>
          <p class="card-body ivu-card-body">{{question}}</p>
          <Row>
            答案：<Input v-model="answer" style="margin-top: 10px"></Input>
          </Row>
          <Row style="margin-top: 10px" >
            <Button @click="addText('1')" type="info">1</Button>
            <Button @click="addText('2')" type="success">2</Button>
            <Button @click="addText('3')" type="warning">3</Button>
            <Button @click="addText('4')" type="error">4</Button>
            <Button @click="addText('5')" type="info">5</Button>
            <Button @click="addText('6')" type="success">6</Button>
            <Button @click="addText('7')" type="warning">7</Button>
            <Button @click="addText('8')" type="error">8</Button>
            <Button @click="addText('9')" type="info">9</Button>
            <Button @click="addText('0')" type="success">0</Button>
            <Button @click="addText('+')" type="warning">+</Button>
            <Button @click="addText('-')" type="error">-</Button>
            <Button @click="addText('*')" type="info">*</Button>
            <Button @click="addText('/')" type="success">/</Button>

          </Row>
          <Row style="margin-top: 10px">
            <!--<Button type="primary" style="float: right;margin-left: 10px">选择题目</Button>-->
            <router-link :to="{path:'/ChooseWork',query:{quesIndex:quesIndex}}">
              <Button type="primary" icon="ios-search">选择题目</Button>
            </router-link>
            <Button type="default" style="float: right;margin-left: 10px" @click="answer=''">重置</Button>
            <Button type="primary" style="float: right" @click="submit">提交</Button>
          </Row>
        </Card>
      </Col>
    </Row>
  </Row>
</template>

<script>
  export default {
    name: "",
    data() {
      return {
        question:"(1+2)*3=",
        answer:"",
        quesIndex:0,
        quesCount:30
      }
    },
    created: function () {
    },
    methods: {
      addText:function (char) {
        this.answer+=char
      },
      submit:function () {
        var ans=this.answer
        var charArray=['0','1','2','3','4','5','6','7','8','9','0','+','-','*','/']
        var flag=true
        for(var index in ans){
          if(!(ans[index] in charArray)){
            flag=false
          }
        }
        if(flag){

        }else {
          this.$Message.error("您输入的答案有误！")
        }
      }
    }
  }
</script>

<style scoped>
  .card-body{
    text-align: center;
    font-family: "Curlz MT";
    font-size: 30px;
    letter-spacing: 10px;
    font-weight: 700;
  }
</style>
