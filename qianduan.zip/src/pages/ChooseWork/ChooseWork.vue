<template>
  <Row>
    <Row style="margin-top: 100px">
      <Col :offset="6" :span="12">
        <Card>
          <p slot="title">选题页面</p>
          <Button type="text" @click="$router.back()" style="margin-left: 10px"><Icon type="chevron-left"></Icon> 返回</Button>
          <Row style="text-align: center">
            <Tooltip :content="item.question"   v-for="item,index in quesArray">
              <Button class="button" :type="(index==quesIndex)?'primary':'default'">
                {{index+1}}
              </Button>
            </Tooltip>
          </Row>
        </Card>
      </Col>
    </Row>
  </Row>
</template>

<script>
  export default {
    name: "",
    data() {
      return {
        quesIndex: 0,
        quesCount: 30,
        quesArray: []
      }
    },
    created: function () {
      this.quesIndex = this.$route.query.quesIndex
      var array = []
      for (var i = 0; i < this.quesCount; i++) {
        array.push({
          question: "1*2+3=",
          answer: "5"
        })
      }
      this.quesArray = array
    },
    methods: {}
  }
</script>

<style scoped>
  .button {
    margin: 10px;
    width: 50px;
  }
</style>
