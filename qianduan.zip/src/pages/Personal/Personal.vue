<template>
  <Row style="margin-top: 20px">
    <Col :offset="1" :span="22">
      <Row :gutter="20">
        <Col :span="6">
          <Card>
            <p slot="title">
              作业完成情况
            </p>
            <Row style="text-align: center">
              <i-circle :percent="80">
                <span class="demo-Circle-inner" style="font-size:24px">80%</span>
              </i-circle>
            </Row>

          </Card>
        </Col>
      </Row>
    </Col>

  </Row>
</template>

<script>
  export default {
    name: "",
    data() {
      return {}
    },
    created: function () {

    },
    methods: {}
  }
</script>

<style scoped>

</style>
